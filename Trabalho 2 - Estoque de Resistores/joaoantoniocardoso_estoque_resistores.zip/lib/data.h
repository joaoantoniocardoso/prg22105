#ifndef __almox_resistores_data
#define __almox_resistores_data

struct resistor{
	unsigned int sre; //6 12 24 48 96 192
	float vlr,
		pot, //em mW (1/4W = 250mW)
		err; //algarismo 1000 vezes maior (5% = 5000)
	unsigned int qtd;
};

#endif