#include "arquivos.h"

int loadfile(struct lista *mlista){
	struct resistor *rtmp;
	FILE *fp;
	fp = fopen(DB, "r");
	system(CLEAR);
	if (fp == NULL){
		#ifdef VERBOSE
			printf("Banco de Dados não encontrado.\n");
		#endif
		//TODO: criar banco de dados
		return -1;
	}else{
		#ifdef VERBOSE
			int a = 0;
			printf("Banco de Dados encontrado.\n");
		#endif
		while(!feof(fp)){
			//aloca o resistor
			rtmp = (struct resistor*)malloc(sizeof(struct resistor));
			checkMalloc(rtmp);
			//carrega os dados do resistor
			fscanf(fp, "%f %u %f %f %u",
				&(*rtmp).vlr,
				&(*rtmp).sre,
				&(*rtmp).err,
				&(*rtmp).pot,
				&(*rtmp).qtd);
			#ifdef VERBOSE 
				if(a>=25){
					// system(CLEAR);
					printf("Carregando... \n");
					a=0;
				}a++;
				printf("%f %u %f %f %u\n",(*rtmp).vlr,(*rtmp).sre,(*rtmp).err,(*rtmp).pot,(*rtmp).qtd);
			#endif
			//insere ele na lista apenas se não for nulo
			if( ((*rtmp).vlr==0) | ((*rtmp).sre==0) | ((*rtmp).err==0) | ((*rtmp).pot==0))
				free(rtmp);
			
			else inserir_item_final(mlista, rtmp);
			// else inserir_item_ordenado(mlista, (void*)rtmp, &comparar_resistor_A, (*rtmp).vlr, (*rtmp).sre, (*rtmp).err, (*rtmp).pot);
		}
	}
	#ifdef VERBOSE
		system(CLEAR);
		printf("Banco de Dados Carregado. Pressione <Enter> para continuar.\n");
	#endif
	return 0;
}

void *vfprintf_resistor(void *dado, int n, va_list vargs){
	if(dado==NULL) return NULL;
	struct resistor *mdado = (struct resistor*)dado;
	FILE *fp;
	fp = fopen(DB, "a");
	fprintf(fp, "%f %u %f %f %u \n",
		(*mdado).vlr,
		(*mdado).sre,
		(*mdado).err,
		(*mdado).pot,
		(*mdado).qtd);
	fclose(fp);
	return NULL;
}

int savefile(struct lista *mlista){
	system(CLEAR);
	
	FILE *fp;
	fp = fopen(DB, "w");
	if (fp == NULL){
		#ifdef VERBOSE
			printf("Banco de Dados não encontrado.\n");
		#endif
		fclose(fp);
		return -1;
	}else{
		#ifdef VERBOSE
			printf("Banco de Dados encontrado.\n");
		#endif
		percorre_lista(mlista, &vfprintf_resistor, 0);
		fclose(fp);
		return 1; //ok
	}
}

