#ifndef __menu_h
#define __menu_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arquivos.h"
#include "lista-duplamente-encadiada-heterogenea.h"
#include "data.h" //onde a struct é definida

	void *comparar_resistor_A(void *dado, int n, va_list vargs);
	void *buscar_resistor(void *dado, int n, va_list vargs);
	void *imprimir_resistor(void *dado, int n, va_list vargs);
	void *alterar_resistor(void *dado, int n, va_list vargs);

	void menu_L(struct lista *mlista);
	void menu_B(struct lista *mlista);
	void menu_M(struct lista *mlista);
	void menu_I(struct lista *mlista);
	void menu_R(struct lista *mlista);
	void menu_S(struct lista *mlista);
	void menu_Q(struct lista *mlista);

#endif