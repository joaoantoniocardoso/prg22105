#include "lista-duplamente-encadiada-heterogenea.h"

struct lista *criar_lista(void* dado_inicial){
	//cria itemlista
	struct itemlista *mitemlista = (struct itemlista*)malloc(sizeof(struct itemlista));
	checkMalloc(mitemlista);
		
	//atribui dado inicial
	(*mitemlista).dado = dado_inicial;

	//anula ponteiros pois é o único item
	(*mitemlista).proximo = NULL;
	(*mitemlista).anterior = NULL;

	// //cria cabecalho
	struct lista *mlista = (struct lista*)malloc(sizeof(struct lista));
	checkMalloc(mlista);
	(*mlista).size = 1;
	(*mlista).start = mitemlista;
	(*mlista).end = mitemlista;

	return mlista;
}

void checkMalloc(void* ptr){
	if (ptr == NULL) {
		printf("Memória cheia. O programa será encerrado. \n");
		getchar();
		exit (EXIT_FAILURE);
	}
}

//insere um item no final da lista
struct itemlista *inserir_item_final(struct lista *mlista, void* dado_inicial){
	struct itemlista *novo_item = (struct itemlista*)malloc(sizeof(struct itemlista));
	checkMalloc(novo_item);
	struct itemlista *ultimo_antigo = (*mlista).end;

	//reaponta
	(*ultimo_antigo).proximo = novo_item;
	(*novo_item).anterior = (*mlista).end;
	(*mlista).end = novo_item;
	(*mlista).size++;

	//atribui dado inicial
	(*novo_item).dado = dado_inicial;

	return novo_item;
}

//insere ordenadamente um item
struct itemlista *inserir_item_ordenado(struct lista *mlista, void* dado_inicial, void *(*functionPtr)(void *dado, int n, va_list vargs), int n, ...){
	struct itemlista *novo_item = (struct itemlista*)malloc(sizeof(struct itemlista));
	checkMalloc(novo_item);
	struct itemlista *mitemlista = (*mlista).start;
	int j;
	va_list args;
	int *r1;
	
	//percorre a lista
	for (j = 0; j < (*mlista).size ; j++){
		while((*mitemlista).dado == NULL) mitemlista = (*mitemlista).proximo; //ignora dados nulos;

		va_start(args, n); //recebe os argumentos da va_list args
		//faz a comparação
		r1 = (int*) (*functionPtr)( (*mitemlista).dado, n, args);
		// printf("::: r1 = %i\n", r1);
		
		if(*r1==0){
			//menor
			getchar();

			//insere o item verificando sua posição na lista
			if((*mlista).size==0){
				//primeiro elemento a ser inserido na lista
				(*novo_item).proximo = (*novo_item).anterior = NULL;
				(*mlista).start = (*mlista).end = novo_item;
			}else if(mitemlista==(*mlista).end){
				//inserir como ultimo
				(*novo_item).proximo = NULL;
				(*novo_item).anterior = mitemlista;
				(*mitemlista).proximo = (*mlista).end = novo_item;
			}else if((*mitemlista).anterior==NULL){
				//inserir como primeiro
				(*novo_item).anterior = NULL;
				(*novo_item).proximo = mitemlista;
				(*mitemlista).anterior = (*mlista).start = novo_item;
			}else{
				//inserir no meio
				(*novo_item).proximo = (*mitemlista).proximo;
				(*novo_item).anterior = (*(*mitemlista).proximo).anterior;
				(*mitemlista).proximo = (*(*mitemlista).proximo).anterior = novo_item ;
			}
			
			(*mlista).size++; //incrementa o tamanho da lista
			(*novo_item).dado = dado_inicial; //atribui dado inicial
			break;

		}else if(*r1==1){
			//maior 
			return NULL;
		}else if(*r1==2) return NULL; //erro: entrada duplicada
			else return NULL; //retorno de functionPtr não esperado!

		mitemlista = (*mitemlista).proximo;
		va_end(args); //limpa a lista de argumentos variaveis
	}

	return novo_item;
}

//Cria uma cópia L2 da lista L1.
void copia_lista(struct lista *L1, struct lista *L2){
	int i;
	struct itemlista *item1 = (*L1).start;
	for (i=0;i<(*L1).size;i++) {
		inserir_item_final(L2, (*item1).dado);
	}
}

//todo: char run_all_list para percorrer a lista inteira ou retornar no primeiro caso de retorno de ponteiro não nulo
void *percorre_lista(struct lista *mlista, void *(*functionPtr)(void *dado, int n, va_list vargs), int n, ...){
	struct itemlista *mitemlista = (*mlista).start;
	int j;
	va_list args;
	void *r1 = NULL, *r2 = NULL;

	//percorre a lista
	for (j = 0; j < (*mlista).size ; j++){
		va_start(args, n); //recebe os argumentos da va_list args
		r1 = (*functionPtr)( (*mitemlista).dado, n, args);
		if (r1!=NULL) r2 = r1;
		mitemlista = (*mitemlista).proximo;
		va_end(args); //limpa a lista de argumentos variaveis
	}

	//retorna
	return r2;
}

void limpa_lista(struct lista *mlista){
	struct itemlista *mitemlista = (*mlista).start;
	int j;
	for (j = 0; j < (*mlista).size ; j++){
		if (mitemlista!=NULL) free((*mitemlista).dado);
		mitemlista = (*mitemlista).proximo;
	}
	free(mlista);
}

struct itemlista *___compara_item_com_dado(struct lista *mlista, void *dado){
	struct itemlista *mitemlista = (*mlista).start;
	int j;

	for (j = 0; j < (*mlista).size ; j++){
		if((*mitemlista).dado == dado) return mitemlista;;
		mitemlista = (*mitemlista).proximo;
	}
	return NULL;
}

void *remover_item(struct lista *mlista, void *dado){
	if (dado==NULL) return NULL; //erro
	else{

		struct itemlista *item = ___compara_item_com_dado(mlista, dado);
		struct itemlista *item_anterior = (*item).anterior;
		struct itemlista *item_proximo = (*item).proximo;
		
		if((*item).proximo == NULL){
			//ultimo
			(*mlista).end = (*item).anterior;
			(*item_anterior).proximo = NULL;

		}else if((*item).anterior == NULL){
			//primeiro
			(*mlista).start = (*item).proximo;
			(*item_proximo).anterior = NULL;
		}else{
			(*item_anterior).proximo = (*item).proximo;
			(*item_proximo).anterior = (*item).anterior;
		}

		(*mlista).size--;
		// free((*item).dado);
		free(item);

		return &((*item).dado); //ok
	}
}